export class User {
    id:number;
    firstName:string;
    lastName:string;
    gender:String;
    address:string;
    emailId:string;
    userName:string;
    password:string;
   
}
